application {
    name="jbpm"
         
    service {
        name = "jbpm"        
    }       
}
